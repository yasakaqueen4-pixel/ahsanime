const {onCall,HttpsError}=require("firebase-functions/v2/https");
const {defineSecret}=require("firebase-functions/params");
const {initializeApp}=require("firebase-admin/app");
const {getFirestore,FieldValue}=require("firebase-admin/firestore");
const {getStorage}=require("firebase-admin/storage");
const fs=require("node:fs/promises");
const os=require("node:os");
const path=require("node:path");
const OpenAIKey=defineSecret("OPENAI_API_KEY");
initializeApp();
const db=getFirestore();

function requireAdmin(req){if(!req.auth||req.auth.token.admin!==true)throw new HttpsError("permission-denied","Admin permission required.");}
function vttFromSegments(segments){let out="WEBVTT\n\n";for(const s of segments||[]){if(typeof s.start!=="number"||typeof s.end!=="number"||!s.text)continue;out+=`${time(s.start)} --> ${time(s.end)}\n${String(s.text).replace(/-->/g,"→").trim()}\n\n`;}return out;}
function time(sec){const ms=Math.max(0,Math.round(sec*1000)),h=Math.floor(ms/3600000),m=Math.floor(ms%3600000/60000),s=Math.floor(ms%60000/1000),x=ms%1000;return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(x).padStart(3,"0")}`;}
async function openai(pathname,options){const r=await fetch("https://api.openai.com/v1/"+pathname,{...options,headers:{Authorization:"Bearer "+process.env.OPENAI_API_KEY,...options.headers}});if(!r.ok)throw new Error("AI provider error "+r.status+": "+(await r.text()).slice(0,800));return r;}
exports.generateSubtitles=onCall({secrets:[OpenAIKey],timeoutSeconds:540,memory:"2GiB",maxInstances:2},async(req)=>{
 requireAdmin(req);process.env.OPENAI_API_KEY=OpenAIKey.value();
 const {animeId}=req.data||{};if(!animeId)throw new HttpsError("invalid-argument","animeId is required");
 const animeRef=db.collection("anime").doc(animeId),snap=await animeRef.get();if(!snap.exists)throw new HttpsError("not-found","Anime not found");
 const anime=snap.data();if(!anime.sourceStoragePath)throw new HttpsError("failed-precondition","Upload source video to Firebase Storage first and set sourceStoragePath.");
 const bucket=getStorage().bucket(),file=bucket.file(anime.sourceStoragePath),[meta]=await file.getMetadata();
 const size=Number(meta.size||0);if(size>24*1024*1024)throw new HttpsError("failed-precondition","This starter function limits audio/video source to 24 MB. For longer episodes, add an audio extraction and chunking pipeline.");
 const tmp=path.join(os.tmpdir(),`ahsanime-${animeId}-${Date.now()}.mp4`);const outputs={};
 try{
  await file.download({destination:tmp});
  const form=new FormData();form.append("file",new Blob([await fs.readFile(tmp)]),path.basename(tmp));form.append("model","whisper-1");form.append("language","ja");form.append("response_format","verbose_json");
  const tr=await openai("audio/transcriptions",{method:"POST",body:form});const transcript=await tr.json();
  const segments=transcript.segments||[];if(!segments.length)throw new Error("No timed speech segments returned.");
  const languages=[["en","Translate Japanese dialogue into natural English."],["hi","Translate Japanese dialogue into natural Hindi written in Devanagari."],["hinglish","Translate Japanese dialogue into natural conversational Hinglish using Roman Hindi." ]];
  for(const [code,instruction] of languages){
   const chunks=[];for(let i=0;i<segments.length;i+=35)chunks.push(segments.slice(i,i+35));
   let translated=[];
   for(const chunk of chunks){
    const payload=chunk.map((s,i)=>({i,start:s.start,end:s.end,text:s.text}));
    const r=await openai("chat/completions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"gpt-4o-mini",temperature:0,messages:[{role:"system",content:`${instruction} Return ONLY valid JSON array. Keep each item index i and preserve start/end values exactly. Schema [{"i":0,"text":"..."}]. Do not add explanations.`},{role:"user",content:JSON.stringify(payload)}]})});
    const j=await r.json();let content=j.choices?.[0]?.message?.content||"[]";content=content.replace(/^```(?:json)?/,"").replace(/```$/,"").trim();const arr=JSON.parse(content);translated.push(...arr);
   }
   const byIndex=new Map(translated.map(x=>[x.i,x.text]));const timed=segments.map((s,i)=>({...s,text:byIndex.get(i)||s.text}));
   const vtt=vttFromSegments(timed),dest=`subtitles/${animeId}/${code}.vtt`,out=bucket.file(dest);
   await out.save(vtt,{contentType:"text/vtt; charset=utf-8",metadata:{cacheControl:"public,max-age=31536000"}});
   const [url]=await out.getSignedUrl({action:"read",expires:"2500-01-01"});
   outputs[code]={path:dest,url};
  }
  await animeRef.update({subtitles:{...(anime.subtitles||{}),...Object.fromEntries(Object.entries(outputs).map(([k,v])=>[k,v.url]))},subtitleGeneratedAt:FieldValue.serverTimestamp(),subtitleSource:"Japanese audio AI"});
  await db.collection("subtitleJobs").add({animeId,status:"completed",createdAt:FieldValue.serverTimestamp(),languages:Object.keys(outputs)});
  return {ok:true,languages:Object.keys(outputs)};
 }catch(e){await db.collection("subtitleJobs").add({animeId,status:"failed",error:String(e.message).slice(0,500),createdAt:FieldValue.serverTimestamp()});throw new HttpsError("internal",e.message);}
 finally{await fs.rm(tmp,{force:true}).catch(()=>{});}
});
