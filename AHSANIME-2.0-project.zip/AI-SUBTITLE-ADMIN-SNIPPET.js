// Add this to public/app.js after imports; wire a button with id="generateSubs".
// import { httpsCallable } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-functions.js";
// const generateSubtitles = httpsCallable(functions, "generateSubtitles");
// $("generateSubs").onclick = async () => {
//   if (!isAdmin || !activeAnime) return toast("Admin only");
//   $("subtitleStatus").textContent = "Generating subtitles…";
//   try {
//     const result = await generateSubtitles({ animeId: activeAnime.id });
//     $("subtitleStatus").textContent = "Saved languages: " + result.data.languages.join(", ");
//   } catch (e) { $("subtitleStatus").textContent = e.message; }
// };
// NOTE: Before using this, upload an audio-only source file to Storage and save its exact object path
// as anime/{animeId}.sourceStoragePath. The included starter form does not yet do this automatically.
