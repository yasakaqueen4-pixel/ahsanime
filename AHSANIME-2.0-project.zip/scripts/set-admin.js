// Run once from project root after installing firebase-admin in a trusted local environment.
// Set GOOGLE_APPLICATION_CREDENTIALS to a service-account JSON file. NEVER upload that file to GitHub.
const admin=require("firebase-admin");
const email=process.argv[2]||"hardikbhuriya41@gmail.com";
admin.initializeApp({credential:admin.credential.applicationDefault(),projectId:"ahsanime"});
(async()=>{const user=await admin.auth().getUserByEmail(email);await admin.auth().setCustomUserClaims(user.uid,{admin:true});console.log(`Admin claim set for ${email}. Sign out/in to refresh token.`);process.exit(0)})().catch(e=>{console.error(e);process.exit(1)});
